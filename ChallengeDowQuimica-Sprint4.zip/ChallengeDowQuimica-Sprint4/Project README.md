SPRINT 4 - OOP (CHALLENGE DOW QU�MICA)

DESCI��O DO TRABALHO:
Elabora��o de aplica��o web; telas do sistema para intera��o dos usu�rios.
Criar projeto web (dynamic web project) no Eclipse ou Netbeans. Codificar as
camadas de controle (servlets) e (views) p�ginas web (JSP); configurar
servidor de aplica��o (Tomcat, Glassfish, Jboss, etc). A aplica��o web deve
prover cadastros, exclus�es, altera��es e buscas diversas, por meio das
p�ginas web (fazer integra��o com a 3 sprint). Realizar as simula��es
necess�rias. 
		
EQUIPE: BYTECH

OBS: N�O ESQUE�A DE COLOCAR SEU LOGIN E SENHA DO SQL SERVER, QUANDO PRECISAR TESTAR O C�DIGO!

link do reposit�rio: https://github.com/bytechnerds/trabalhos-2SI