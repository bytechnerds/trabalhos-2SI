package br.fiap.entidade;

public enum TipoDeficiencia {
	CEGUEIRA, BAIXAVISAO, DALTONISMO;
}
