package br.fiap.entidade;

public enum TipoNavegador {
		CHROME, FIREFOX, EDGE, OPERA, SAFARI, BRAVE, INTERNETEXPLORER;
}
